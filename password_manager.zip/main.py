import sys
import argparse
from app import app

# Import the app for Gunicorn to use
# This is needed for the server to run

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Gerenciador de Senhas')
    parser.add_argument('--cli', action='store_true', help='Executar no modo de linha de comando')
    args = parser.parse_args()
    
    if args.cli:
        # Run in CLI mode
        from app import run_cli_mode
        run_cli_mode()
    else:
        # Run in web mode
        app.run(host='0.0.0.0', port=5000, debug=True)
