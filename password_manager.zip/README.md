# Gerenciador de Senhas

Um gerenciador de senhas completo com interface web e de linha de comando (CLI).

## Recursos

- Interface web amigável
- Modo de linha de comando para uso rápido
- Geração de senhas fortes
- Armazenamento seguro de senhas com criptografia
- Capacidade de copiar senhas para a área de transferência
- Exportação e importação de dados

## Uso da Interface Web

1. Execute a aplicação web:
   ```
   gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
   ```

2. Acesse a aplicação em seu navegador em `http://localhost:5000`

3. Crie uma conta e faça login

4. Use o dashboard para gerenciar suas senhas

## Uso da Linha de Comando (CLI)

### Menu Interativo

Para executar no modo interativo:

```bash
python cli.py
```

Isso mostrará um menu onde você pode adicionar ou visualizar senhas.

### Comandos Diretos

Adicionar uma senha:

```bash
python cli.py --action add --service "Nome do Serviço" --username "seu_usuario"
```

Se você omitir a senha (--password), uma senha forte será gerada automaticamente.

Ver uma senha:

```bash
python cli.py --action view --service "Nome do Serviço"
```

### Opções

- `--file`, `-f`: Especificar o arquivo para armazenar as senhas (padrão: senhas.json)
- `--action`, `-a`: Ação a executar (add, view, run)
- `--service`, `-s`: Nome do serviço
- `--username`, `-u`: Nome de usuário
- `--password`, `-p`: Senha (omita para gerar automaticamente)
- `--length`, `-l`: Comprimento da senha gerada (padrão: 12)

## Segurança

Todas as senhas são criptografadas usando o algoritmo Fernet da biblioteca cryptography. 
As senhas são protegidas com sua senha mestra e são armazenadas de forma segura.

## Requisitos

- Python 3.6+
- Flask
- Cryptography