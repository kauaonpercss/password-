#!/usr/bin/env python
import argparse
import os
import sys
from cli_password_manager import CliPasswordManager

def print_header():
    """Print a nice header for the application"""
    print("\n" + "=" * 40)
    print("    GERENCIADOR DE SENHAS - CLI MODE")
    print("=" * 40)
    print("\nUm gerenciador simples para suas senhas.\n")

def main():
    """Main CLI entry point"""
    print_header()
    
    parser = argparse.ArgumentParser(description='Gerenciador de Senhas CLI')
    parser.add_argument('--file', '-f', default='senhas.json', 
                       help='Arquivo para armazenar as senhas (padrão: senhas.json)')
    parser.add_argument('--action', '-a', choices=['add', 'view', 'run'],
                        default='run', help='Ação a executar (adicionar senha, ver senha, ou executar menu interativo)')
    parser.add_argument('--service', '-s', help='Nome do serviço (para as ações add/view)')
    parser.add_argument('--username', '-u', help='Nome de usuário (para a ação add)')
    parser.add_argument('--password', '-p', help='Senha (para a ação add, omita para gerar automaticamente)')
    parser.add_argument('--length', '-l', type=int, default=12, 
                        help='Comprimento da senha gerada (padrão: 12)')
    
    args = parser.parse_args()
    
    # Initialize the password manager
    manager = CliPasswordManager(json_file=args.file)
    
    # Handle different actions
    if args.action == 'add':
        if not args.service:
            print("Erro: O nome do serviço é obrigatório para adicionar uma senha.")
            parser.print_help()
            sys.exit(1)
            
        username = args.username or input("Usuário: ")
        
        if args.password:
            password = args.password
        else:
            password = manager.gerar(args.length)
            print(f"Senha gerada: {password}")
            
        dados = manager.carregar()
        dados[args.service] = {"usuario": username, "senha": password}
        manager.salvar(dados)
        
        print(f"Senha para {args.service} salva com sucesso!")
        
    elif args.action == 'view':
        if not args.service:
            print("Erro: O nome do serviço é obrigatório para visualizar uma senha.")
            parser.print_help()
            sys.exit(1)
            
        dados = manager.carregar()
        
        if args.service in dados:
            print(f"\nDetalhes para {args.service}:")
            print(f"Usuário: {dados[args.service]['usuario']}")
            print(f"Senha  : {dados[args.service]['senha']}")
        else:
            print(f"Serviço '{args.service}' não encontrado.")
            
    else:  # run interactive menu
        manager.run_cli()

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\nOperação cancelada pelo usuário. Saindo...")
        sys.exit(0)