import os
import json
import logging
import sys
import argparse
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from password_manager import PasswordManager
from crypto import generate_key, encrypt_password, decrypt_password

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev_secret_key")

# Ensure data directory exists
if not os.path.exists('data'):
    os.makedirs('data')

# Path to user credentials file
USERS_FILE = 'data/users.json'

# Create users file if it doesn't exist
if not os.path.exists(USERS_FILE):
    with open(USERS_FILE, 'w') as f:
        json.dump({}, f)

# Initialize password manager
password_manager = PasswordManager()

# CLI functionality
def run_cli_mode():
    """Run the password manager in CLI mode"""
    import getpass
    import random
    import string
    
    def carregar():
        if os.path.exists("senhas.json"):
            with open("senhas.json", "r") as f:
                return json.load(f)
        return {}
    
    def salvar(dados):
        with open("senhas.json", "w") as f:
            json.dump(dados, f, indent=4)
    
    def gerar(tam=12):
        chars = string.ascii_letters + string.digits + string.punctuation
        return ''.join(random.choice(chars) for _ in range(tam))
    
    def adicionar():
        s = input("Serviço: ")
        u = input("Usuário: ")
        p = getpass.getpass("Senha (Enter para gerar): ")
        
        if not p:
            p = gerar()
            print("Senha gerada:", p)
        
        dados = carregar()
        dados[s] = {"usuario": u, "senha": p}
        salvar(dados)
        
        print("Salvo.")
    
    def ver():
        s = input("Serviço: ")
        dados = carregar()
        
        if s in dados:
            print("Usuário:", dados[s]["usuario"])
            print("Senha:", dados[s]["senha"])
        else:
            print("Não encontrado.")
    
    def menu():
        while True:
            print("\n1. Adicionar\n2. Ver\n3. Sair")
            op = input("Opção: ")
            
            if op == "1":
                adicionar()
            elif op == "2":
                ver()
            elif op == "3":
                break
            else:
                print("Inválido.")
    
    # Run the CLI menu
    menu()

# Login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('Por favor, faça login para acessar esta página', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Input validation
        if not username or not password:
            flash('Por favor, preencha todos os campos', 'danger')
            return render_template('login.html')
        
        # Load users from file
        try:
            with open(USERS_FILE, 'r') as f:
                users = json.load(f)
        except Exception as e:
            logging.error(f"Error loading users file: {e}")
            flash('Erro no sistema, tente novamente mais tarde', 'danger')
            return render_template('login.html')
        
        # Check if user exists and password is correct
        if username in users and check_password_hash(users[username]['password'], password):
            session['username'] = username
            session['key'] = generate_key(password)
            flash(f'Bem-vindo, {username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Nome de usuário ou senha incorretos', 'danger')
            
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Input validation
        if not username or not password or not confirm_password:
            flash('Por favor, preencha todos os campos', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('As senhas não coincidem', 'danger')
            return render_template('register.html')
        
        # Load existing users
        try:
            with open(USERS_FILE, 'r') as f:
                users = json.load(f)
        except Exception as e:
            logging.error(f"Error loading users file: {e}")
            flash('Erro no sistema, tente novamente mais tarde', 'danger')
            return render_template('register.html')
        
        # Check if username already exists
        if username in users:
            flash('Nome de usuário já existe', 'danger')
            return render_template('register.html')
        
        # Add new user
        user_data = {
            'password': generate_password_hash(password),
            'passwords_file': f'data/{username}_passwords.json'
        }
        
        users[username] = user_data
        
        # Save updated users
        try:
            with open(USERS_FILE, 'w') as f:
                json.dump(users, f)
                
            # Create empty passwords file for the user
            with open(user_data['passwords_file'], 'w') as f:
                json.dump([], f)
                
            flash('Conta criada com sucesso! Agora você pode fazer login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            logging.error(f"Error saving user data: {e}")
            flash('Erro ao criar conta, tente novamente mais tarde', 'danger')
            
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Você saiu com sucesso', 'success')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    username = session.get('username')
    key = session.get('key')
    
    # Load user data
    try:
        with open(USERS_FILE, 'r') as f:
            users = json.load(f)
            
        user_data = users.get(username)
        if not user_data:
            flash('Erro ao carregar dados do usuário', 'danger')
            return redirect(url_for('logout'))
            
        # Load passwords
        passwords = password_manager.get_passwords(user_data['passwords_file'])
        
        # Decrypt passwords for display
        decrypted_passwords = []
        for pwd in passwords:
            try:
                decrypted = {
                    'id': pwd['id'],
                    'title': pwd['title'],
                    'username': pwd['username'],
                    'url': pwd['url'],
                    'password': decrypt_password(pwd['password'], key),
                    'notes': pwd.get('notes', '')
                }
                decrypted_passwords.append(decrypted)
            except Exception as e:
                logging.error(f"Error decrypting password: {e}")
                
        return render_template('dashboard.html', passwords=decrypted_passwords)
    except Exception as e:
        logging.error(f"Error in dashboard: {e}")
        flash('Erro ao carregar seus dados', 'danger')
        return redirect(url_for('logout'))

@app.route('/add_password', methods=['POST'])
@login_required
def add_password():
    username = session.get('username')
    key = session.get('key')
    
    # Get form data
    title = request.form.get('title')
    site_username = request.form.get('site_username')
    password = request.form.get('password')
    url = request.form.get('url')
    notes = request.form.get('notes', '')
    
    # Validate input
    if not title or not site_username or not password:
        flash('Título, nome de usuário e senha são obrigatórios', 'danger')
        return redirect(url_for('dashboard'))
    
    # Load user data
    try:
        with open(USERS_FILE, 'r') as f:
            users = json.load(f)
            
        user_data = users.get(username)
        if not user_data:
            flash('Erro ao carregar dados do usuário', 'danger')
            return redirect(url_for('logout'))
        
        # Encrypt password
        encrypted_password = encrypt_password(password, key)
        
        # Add password
        password_manager.add_password(
            user_data['passwords_file'],
            title,
            site_username,
            encrypted_password,
            url,
            notes
        )
        
        flash('Senha adicionada com sucesso', 'success')
    except Exception as e:
        logging.error(f"Error adding password: {e}")
        flash('Erro ao adicionar senha', 'danger')
        
    return redirect(url_for('dashboard'))

@app.route('/delete_password/<int:password_id>', methods=['POST'])
@login_required
def delete_password(password_id):
    username = session.get('username')
    
    try:
        with open(USERS_FILE, 'r') as f:
            users = json.load(f)
            
        user_data = users.get(username)
        if not user_data:
            flash('Erro ao carregar dados do usuário', 'danger')
            return redirect(url_for('logout'))
        
        # Delete password
        success = password_manager.delete_password(user_data['passwords_file'], password_id)
        
        if success:
            flash('Senha excluída com sucesso', 'success')
        else:
            flash('Erro ao excluir senha', 'danger')
    except Exception as e:
        logging.error(f"Error deleting password: {e}")
        flash('Erro ao excluir senha', 'danger')
        
    return redirect(url_for('dashboard'))

@app.route('/generate_password', methods=['GET'])
def generate_password():
    length = request.args.get('length', 12, type=int)
    include_uppercase = request.args.get('uppercase', 'true') == 'true'
    include_lowercase = request.args.get('lowercase', 'true') == 'true'
    include_numbers = request.args.get('numbers', 'true') == 'true'
    include_symbols = request.args.get('symbols', 'true') == 'true'
    
    # Generate password
    password = password_manager.generate_password(
        length, 
        include_uppercase, 
        include_lowercase, 
        include_numbers, 
        include_symbols
    )
    
    return {'password': password}

@app.route('/update_password/<int:password_id>', methods=['POST'])
@login_required
def update_password(password_id):
    username = session.get('username')
    key = session.get('key')
    
    # Get form data
    title = request.form.get('title')
    site_username = request.form.get('site_username')
    password = request.form.get('password')
    url = request.form.get('url')
    notes = request.form.get('notes', '')
    
    # Validate input
    if not title or not site_username or not password:
        flash('Título, nome de usuário e senha são obrigatórios', 'danger')
        return redirect(url_for('dashboard'))
    
    try:
        with open(USERS_FILE, 'r') as f:
            users = json.load(f)
            
        user_data = users.get(username)
        if not user_data:
            flash('Erro ao carregar dados do usuário', 'danger')
            return redirect(url_for('logout'))
        
        # Encrypt password
        encrypted_password = encrypt_password(password, key)
        
        # Update password
        success = password_manager.update_password(
            user_data['passwords_file'],
            password_id,
            title,
            site_username,
            encrypted_password,
            url,
            notes
        )
        
        if success:
            flash('Senha atualizada com sucesso', 'success')
        else:
            flash('Erro ao atualizar senha', 'danger')
    except Exception as e:
        logging.error(f"Error updating password: {e}")
        flash('Erro ao atualizar senha', 'danger')
        
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
