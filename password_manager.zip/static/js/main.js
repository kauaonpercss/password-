document.addEventListener('DOMContentLoaded', function() {
    // Toggle password visibility
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function() {
            const passwordInput = this.parentElement.querySelector('input');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
    
    // Copy password to clipboard
    document.querySelectorAll('.copy-password').forEach(button => {
        button.addEventListener('click', function() {
            const password = this.getAttribute('data-password');
            
            // Create a temporary input element
            const tempInput = document.createElement('input');
            tempInput.value = password;
            document.body.appendChild(tempInput);
            
            // Select and copy the password
            tempInput.select();
            document.execCommand('copy');
            
            // Remove the temporary input
            document.body.removeChild(tempInput);
            
            // Show feedback
            const originalHtml = this.innerHTML;
            this.innerHTML = '<i class="fas fa-check"></i>';
            
            setTimeout(() => {
                this.innerHTML = originalHtml;
            }, 1500);
        });
    });
    
    // Password generator
    const generateBtn = document.getElementById('generatePassword');
    if (generateBtn) {
        generateBtn.addEventListener('click', function() {
            const length = document.getElementById('passwordLength').value;
            const uppercase = document.getElementById('includeUppercase').checked;
            const lowercase = document.getElementById('includeLowercase').checked;
            const numbers = document.getElementById('includeNumbers').checked;
            const symbols = document.getElementById('includeSymbols').checked;
            
            // Generate password via API
            fetch(`/generate_password?length=${length}&uppercase=${uppercase}&lowercase=${lowercase}&numbers=${numbers}&symbols=${symbols}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('password').value = data.password;
                })
                .catch(error => {
                    console.error('Error generating password:', error);
                });
        });
    }
});
