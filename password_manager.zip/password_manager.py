import json
import os
import random
import string

class PasswordManager:
    def __init__(self):
        # Ensure data directory exists
        if not os.path.exists('data'):
            os.makedirs('data')
    
    def get_passwords(self, passwords_file):
        """Get all passwords for a user"""
        try:
            if os.path.exists(passwords_file):
                with open(passwords_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            print(f"Error loading passwords: {e}")
            return []
    
    def add_password(self, passwords_file, title, username, password, url="", notes=""):
        """Add a new password entry"""
        try:
            passwords = self.get_passwords(passwords_file)
            
            # Generate a new ID
            new_id = 1
            if passwords:
                new_id = max(pwd['id'] for pwd in passwords) + 1
            
            # Create password entry
            password_entry = {
                'id': new_id,
                'title': title,
                'username': username,
                'password': password,
                'url': url,
                'notes': notes
            }
            
            passwords.append(password_entry)
            
            # Save passwords
            with open(passwords_file, 'w') as f:
                json.dump(passwords, f)
                
            return True
        except Exception as e:
            print(f"Error adding password: {e}")
            return False
    
    def delete_password(self, passwords_file, password_id):
        """Delete a password entry by ID"""
        try:
            passwords = self.get_passwords(passwords_file)
            
            # Find password with matching ID
            filtered_passwords = [pwd for pwd in passwords if pwd['id'] != password_id]
            
            if len(filtered_passwords) == len(passwords):
                # No password was removed
                return False
            
            # Save updated passwords
            with open(passwords_file, 'w') as f:
                json.dump(filtered_passwords, f)
                
            return True
        except Exception as e:
            print(f"Error deleting password: {e}")
            return False
    
    def update_password(self, passwords_file, password_id, title, username, password, url="", notes=""):
        """Update an existing password entry"""
        try:
            passwords = self.get_passwords(passwords_file)
            
            # Find password with matching ID
            for pwd in passwords:
                if pwd['id'] == password_id:
                    pwd['title'] = title
                    pwd['username'] = username
                    pwd['password'] = password
                    pwd['url'] = url
                    pwd['notes'] = notes
                    
                    # Save updated passwords
                    with open(passwords_file, 'w') as f:
                        json.dump(passwords, f)
                        
                    return True
            
            return False
        except Exception as e:
            print(f"Error updating password: {e}")
            return False
    
    def generate_password(self, length=12, uppercase=True, lowercase=True, numbers=True, symbols=True):
        """Generate a random password"""
        # Define character sets
        chars = ""
        
        if uppercase:
            chars += string.ascii_uppercase
        if lowercase:
            chars += string.ascii_lowercase
        if numbers:
            chars += string.digits
        if symbols:
            chars += string.punctuation
        
        # Default to all character types if none were selected
        if not chars:
            chars = string.ascii_letters + string.digits + string.punctuation
        
        # Generate password
        password = ''.join(random.choice(chars) for _ in range(length))
        
        return password
