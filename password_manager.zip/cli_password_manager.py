import json
import os
import random
import string
from getpass import getpass
from crypto import generate_key, encrypt_password, decrypt_password

class CliPasswordManager:
    def __init__(self, json_file='senhas.json'):
        self.json_file = json_file
        # Create file if it doesn't exist
        if not os.path.exists(self.json_file):
            with open(self.json_file, 'w') as f:
                json.dump({}, f)
    
    def carregar(self):
        """Load passwords from file"""
        if os.path.exists(self.json_file):
            with open(self.json_file, "r") as f:
                return json.load(f)
        return {}
    
    def salvar(self, dados):
        """Save passwords to file"""
        with open(self.json_file, "w") as f:
            json.dump(dados, f, indent=4)
    
    def gerar(self, tam=12):
        """Generate a random password"""
        chars = string.ascii_letters + string.digits + string.punctuation
        return ''.join(random.choice(chars) for _ in range(tam))
    
    def adicionar(self):
        """Add a new password"""
        s = input("Serviço: ")
        u = input("Usuário: ")
        p = getpass("Senha (Enter para gerar): ")
        
        if not p:
            p = self.gerar()
            print("Senha gerada:", p)
        
        dados = self.carregar()
        dados[s] = {"usuario": u, "senha": p}
        self.salvar(dados)
        
        print("Salvo.")
    
    def ver(self):
        """View a password"""
        s = input("Serviço: ")
        dados = self.carregar()
        
        if s in dados:
            print("Usuário:", dados[s]["usuario"])
            print("Senha :", dados[s]["senha"])
        else:
            print("Não encontrado.")
    
    def run_cli(self):
        """Run CLI menu"""
        while True:
            print("\n1. Adicionar\n2. Ver\n3. Sair")
            op = input("Opção: ")
            
            if op == "1":
                self.adicionar()
            elif op == "2":
                self.ver()
            elif op == "3":
                break
            else:
                print("Inválido.")

# Run CLI interface if executed directly
if __name__ == "__main__":
    manager = CliPasswordManager()
    manager.run_cli()